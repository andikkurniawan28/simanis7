<div class="form-group">
    <label for="file"><strong>{{ strtoupper("file excel") }}</strong></label>
    <input type="file" class="form-control-file" id="file" name="file" required>
</div>
