           <li class="nav-item">
                <a class="nav-link" href="{{ $route }}">
                    <i class="fas fa-fw fa-{{ $icon }}"></i>
                    <span>{{ strtoupper(str_replace("_", " ", $title)) }}</span></a>
            </li>
