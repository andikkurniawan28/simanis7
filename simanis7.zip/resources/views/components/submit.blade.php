<button type="submit" class="btn btn-primary">{{ ucfirst("submit") }}</button>
