    <div class="footer py-4 d-flex flex-lg-column" id="kt_footer">
        <div class="container-xxl d-flex flex-column flex-md-row flex-stack">
            <div class="text-dark order-2 order-md-1">
                <span class="text-gray-400 fw-bold me-1">&copy; Copyright by <a href="https://validdatasolusi.co.id/" target="_blank">PT. Valid Data Solusi</a></span>
            </div>
        </div>
    </div>
