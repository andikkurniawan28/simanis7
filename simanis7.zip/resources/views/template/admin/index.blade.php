@extends("template.admin.master")

@section("content")
    @include("template.admin.table")
@endsection
