@extends("template.admin.master")

@section("content")
    @yield("app")
@endsection
