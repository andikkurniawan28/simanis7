@extends("template.admin.master")

@section("content")
    @include("template.admin.table2")
@endsection
