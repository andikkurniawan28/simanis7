<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MataUang extends Model
{
    protected $table = "uang";
    protected $guarded = [];
    public $timestamps = false;
}
