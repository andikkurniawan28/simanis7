<?php

namespace App\Http\Controllers\Api;

use App\Stock;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;

class StockController extends Controller
{
    public function index($status = null){
        //
    }
}
